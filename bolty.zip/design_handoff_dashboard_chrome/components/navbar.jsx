/* global React */
const { useState } = React;

function NetPill() {
  return (
    <div className="nav-net">
      <span className="nav-net-dot"/>
      <span>Monad</span>
      <span className="nav-net-sep">·</span>
      <span className="nav-net-block">#8,492,118</span>
    </div>
  );
}

function CommandSearch({ wide }) {
  return (
    <button className={`nav-cmd ${wide ? 'nav-cmd-wide' : ''}`}>
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="11" cy="11" r="7"/><path d="m21 21-4.35-4.35"/>
      </svg>
      <span>Search agents, repos, addresses, tx…</span>
      <span className="nav-cmd-right">
        <kbd>⌘</kbd><kbd>K</kbd>
      </span>
    </button>
  );
}

function NotifBell({ count }) {
  return (
    <button className="nav-icon-btn" title="Notifications">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
        <path d="M6 8a6 6 0 1 1 12 0c0 6 3 7 3 7H3s3-1 3-7"/><path d="M10 20a2 2 0 0 0 4 0"/>
      </svg>
      {count > 0 && <span className="nav-icon-badge">{count}</span>}
    </button>
  );
}

// ─────────────────────────────────────────────────────────────────
// VARIANT 1 — Minimal. Breadcrumb · cmd-K · network · bell · avatar.
// ─────────────────────────────────────────────────────────────────
function MinimalNavbar({ crumbs }) {
  return (
    <header className="nav nav-minimal">
      <nav className="nav-crumbs">
        {crumbs.map((c, i) => (
          <React.Fragment key={i}>
            {i > 0 && <span className="nav-crumb-sep">/</span>}
            <a href="#" className={`nav-crumb ${i === crumbs.length - 1 ? 'is-current' : ''}`}>{c}</a>
          </React.Fragment>
        ))}
      </nav>

      <div className="nav-spacer"/>

      <CommandSearch/>
      <NetPill/>

      <div className="nav-divider"/>

      <NotifBell count={3}/>

      <button className="nav-avatar">
        <span className="nav-avatar-img">AR</span>
        <span className="nav-avatar-status"/>
      </button>
    </header>
  );
}

// ─────────────────────────────────────────────────────────────────
// VARIANT 2 — Power-user. Adds inline metrics ticker + quick actions.
// ─────────────────────────────────────────────────────────────────
function PowerNavbar({ crumbs }) {
  return (
    <header className="nav nav-power">
      <nav className="nav-crumbs">
        {crumbs.map((c, i) => (
          <React.Fragment key={i}>
            {i > 0 && <span className="nav-crumb-sep">/</span>}
            <a href="#" className={`nav-crumb ${i === crumbs.length - 1 ? 'is-current' : ''}`}>{c}</a>
          </React.Fragment>
        ))}
      </nav>

      {/* Inline ticker */}
      <div className="nav-ticker">
        <div className="nav-tk">
          <span className="nav-tk-lbl">MON</span>
          <span className="nav-tk-val">$0.328</span>
          <span className="nav-tk-delta nav-tk-up">+4.21%</span>
        </div>
        <div className="nav-tk-sep"/>
        <div className="nav-tk">
          <span className="nav-tk-lbl">GAS</span>
          <span className="nav-tk-val">12 gwei</span>
        </div>
        <div className="nav-tk-sep"/>
        <div className="nav-tk">
          <span className="nav-tk-lbl">RAYS</span>
          <span className="nav-tk-val">2,847</span>
          <span className="nav-tk-delta nav-tk-up">+18</span>
        </div>
      </div>

      <div className="nav-spacer"/>

      <CommandSearch/>

      <button className="nav-pill nav-pill-primary">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M12 5v14M5 12h14"/>
        </svg>
        Deploy agent
      </button>

      <div className="nav-divider"/>

      <NetPill/>
      <NotifBell count={3}/>

      <button className="nav-avatar">
        <span className="nav-avatar-img">AR</span>
        <span className="nav-avatar-status"/>
      </button>
    </header>
  );
}

window.NavbarVariants = { minimal: MinimalNavbar, power: PowerNavbar };
