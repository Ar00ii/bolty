/* global React */
const { useState } = React;

// ─────────────────────────────────────────────────────────────────
// Icon set — minimal, 1.25px stroke, 16px viewBox. Matches Lucide
// language used elsewhere in the app but tightened for sidebar use.
// ─────────────────────────────────────────────────────────────────
const Icon = ({ d, size = 16, stroke = 1.5 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
       stroke="currentColor" strokeWidth={stroke}
       strokeLinecap="round" strokeLinejoin="round">
    {d}
  </svg>
);

const Icons = {
  home:    <Icon d={<><path d="M3 11l9-7 9 7v9a2 2 0 0 1-2 2h-4v-7h-6v7H5a2 2 0 0 1-2-2z"/></>}/>,
  bot:     <Icon d={<><rect x="4" y="8" width="16" height="12" rx="2"/><path d="M12 2v4"/><circle cx="9" cy="14" r="1"/><circle cx="15" cy="14" r="1"/><path d="M9 18h6"/></>}/>,
  repos:   <Icon d={<><path d="M4 4h11l5 5v11a1 1 0 0 1-1 1H4z"/><path d="M14 4v5h6"/><circle cx="9" cy="15" r="2"/><path d="M9 17v3"/></>}/>,
  msg:     <Icon d={<><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></>}/>,
  globe:   <Icon d={<><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></>}/>,
  spark:   <Icon d={<><path d="M13 2 4 14h7l-1 8 9-12h-7l1-8z"/></>}/>,
  brief:   <Icon d={<><rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></>}/>,
  book:    <Icon d={<><path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v18H6.5A2.5 2.5 0 0 0 4 22.5z"/><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/></>}/>,
  user:    <Icon d={<><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>}/>,
  key:     <Icon d={<><circle cx="8" cy="12" r="4"/><path d="M12 12h10M18 8v4M22 8v4"/></>}/>,
  cart:    <Icon d={<><path d="M3 4h2l2 13h12l2-9H6"/><circle cx="9" cy="20" r="1.5"/><circle cx="17" cy="20" r="1.5"/></>}/>,
  cog:     <Icon d={<><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.3l2-1.5-2-3.4-2.4.9a7 7 0 0 0-2.2-1.3L14 3h-4l-.3 2.4a7 7 0 0 0-2.2 1.3l-2.4-.9-2 3.4 2 1.5A7 7 0 0 0 5 12c0 .4 0 .9.1 1.3l-2 1.5 2 3.4 2.4-.9a7 7 0 0 0 2.2 1.3L10 21h4l.3-2.4a7 7 0 0 0 2.2-1.3l2.4.9 2-3.4-2-1.5c.1-.4.1-.9.1-1.3z"/></>}/>,
  chev:    <Icon d={<><path d="m9 6 6 6-6 6"/></>} size={14}/>,
  plus:    <Icon d={<><path d="M12 5v14M5 12h14"/></>} size={14}/>,
  pin:     <Icon d={<><path d="M12 2v6m0 0-4 4h8zM8 18h8M12 12v6"/></>} size={14}/>,
  swap:    <Icon d={<><path d="M7 7h13l-3-3M17 17H4l3 3"/></>} size={14}/>,
  flame:   <Icon d={<><path d="M12 22a7 7 0 0 0 7-7c0-3-2-5-3-7s-1-5-4-6c0 4-2 5-3 7s-4 4-4 6a7 7 0 0 0 7 7z"/></>} size={14}/>,
};

// ─────────────────────────────────────────────────────────────────
// Nav model — same hierarchy as the existing Sidebar.tsx
// ─────────────────────────────────────────────────────────────────
const NAV = [
  { section: 'Workspace', items: [
    { label: 'Overview',   icon: 'home',  href: '/',         active: true, kbd: 'G O' },
    { label: 'My Profile', icon: 'user',  href: '/profile',  kbd: 'G P' },
  ]},
  { section: 'Marketplace', items: [
    { label: 'Agents',       icon: 'bot',   href: '/market/agents', count: 1284, hot: true },
    { label: 'Repositories', icon: 'repos', href: '/market/repos',  count: 892 },
    { label: 'Services',     icon: 'brief', href: '/services',      count: 47 },
  ]},
  { section: 'Network', items: [
    { label: 'Global Chat', icon: 'globe', href: '/chat',     badge: '128 live' },
    { label: 'Messages',    icon: 'msg',   href: '/dm',       count: 3, dot: true },
    { label: 'Boost',       icon: 'spark', href: '/boost' },
  ]},
  { section: 'Resources', items: [
    { label: 'API Keys',  icon: 'key',  href: '/api-keys' },
    { label: 'Docs',      icon: 'book', href: '/docs' },
    { label: 'Settings',  icon: 'cog',  href: '/settings' },
  ]},
];

const PINNED = [
  { label: 'CodeReviewer-v3', icon: 'bot',   color: '#836EF9' },
  { label: 'monorepo-toolkit', icon: 'repos', color: '#06B6D4' },
  { label: 'price-oracle.eth', icon: 'spark', color: '#EC4899' },
];

// ─────────────────────────────────────────────────────────────────
// VARIANT A — Compact rail (60px). Icons + tooltips. For power users.
// ─────────────────────────────────────────────────────────────────
function RailSidebar() {
  const flat = NAV.flatMap(s => s.items);
  return (
    <aside className="rail-sidebar">
      <div className="rail-logo">
        <div className="rail-mark">B</div>
      </div>
      <nav className="rail-nav">
        {flat.map((item, i) => (
          <button key={i} className={`rail-item ${item.active ? 'is-active' : ''}`} title={item.label}>
            <span className="rail-icon">{Icons[item.icon]}</span>
            {item.dot && <span className="rail-dot"/>}
            {item.hot && <span className="rail-hot"/>}
            {item.active && <span className="rail-active-bar"/>}
            <span className="rail-tooltip">{item.label}</span>
          </button>
        ))}
      </nav>
      <div className="rail-foot">
        <button className="rail-item" title="Add">
          <span className="rail-icon">{Icons.plus}</span>
        </button>
        <div className="rail-avatar">AR</div>
      </div>
    </aside>
  );
}

// ─────────────────────────────────────────────────────────────────
// VARIANT B — Standard (260px). Workspace switcher, sectioned, pinned, mono section labels.
// ─────────────────────────────────────────────────────────────────
function StandardSidebar() {
  const [wsOpen, setWsOpen] = useState(false);
  return (
    <aside className="std-sidebar">
      {/* Workspace switcher */}
      <button className="ws-switcher" onClick={() => setWsOpen(v => !v)}>
        <div className="ws-mark">B</div>
        <div className="ws-meta">
          <div className="ws-name">Aroii's Workspace</div>
          <div className="ws-net">
            <span className="ws-net-dot"/> Monad Mainnet
          </div>
        </div>
        <span className="ws-chev">{Icons.swap}</span>
      </button>

      {/* Search inline */}
      <div className="std-search">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="11" cy="11" r="7"/><path d="m21 21-4.35-4.35"/>
        </svg>
        <span>Jump to…</span>
        <kbd>⌘K</kbd>
      </div>

      {/* Sections */}
      <div className="std-scroll">
        {NAV.map((sect, si) => (
          <div key={si} className="std-section">
            <div className="std-label">{sect.section}</div>
            {sect.items.map((item, i) => (
              <a key={i} href="#" className={`std-item ${item.active ? 'is-active' : ''}`}>
                <span className="std-marker">{item.active ? '›' : ''}</span>
                <span className="std-icon">{Icons[item.icon]}</span>
                <span className="std-label-txt">{item.label}</span>
                {item.hot && <span className="std-hot">{Icons.flame}</span>}
                {item.badge && <span className="std-badge std-badge-live"><span className="live-dot"/>{item.badge}</span>}
                {item.count != null && !item.badge && (
                  <span className={`std-count ${item.dot ? 'std-count-alert' : ''}`}>{item.count}</span>
                )}
                {item.kbd && <span className="std-kbd">{item.kbd}</span>}
              </a>
            ))}
          </div>
        ))}

        {/* Pinned */}
        <div className="std-section">
          <div className="std-label std-label-pinned">
            <span>Pinned</span>
            <button className="std-label-add" title="Pin item">{Icons.plus}</button>
          </div>
          {PINNED.map((p, i) => (
            <a key={i} href="#" className="std-item std-item-pinned">
              <span className="std-marker"/>
              <span className="std-pin-dot" style={{ background: p.color }}/>
              <span className="std-label-txt std-label-mono">{p.label}</span>
            </a>
          ))}
        </div>
      </div>

      {/* Footer card — wallet/balance */}
      <div className="std-footer">
        <div className="std-foot-top">
          <div className="std-foot-net">
            <span className="ws-net-dot"/>
            <span className="std-foot-mono">0x4f2a…E91c</span>
          </div>
          <button className="std-foot-disconnect">disconnect</button>
        </div>
        <div className="std-foot-bal">
          <div>
            <div className="std-foot-bal-num">12.847</div>
            <div className="std-foot-bal-lbl">MON · $4,218.20</div>
          </div>
          <button className="std-foot-bal-btn">Buy →</button>
        </div>
      </div>
    </aside>
  );
}

// ─────────────────────────────────────────────────────────────────
// VARIANT C — Workspace (280px). Standard + activity stream + boost meter.
// ─────────────────────────────────────────────────────────────────
function WorkspaceSidebar() {
  return (
    <aside className="ws-sidebar">
      <button className="ws-switcher">
        <div className="ws-mark">B</div>
        <div className="ws-meta">
          <div className="ws-name">Aroii's Workspace</div>
          <div className="ws-net"><span className="ws-net-dot"/> Monad Mainnet</div>
        </div>
        <span className="ws-chev">{Icons.swap}</span>
      </button>

      <div className="std-search">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="11" cy="11" r="7"/><path d="m21 21-4.35-4.35"/>
        </svg>
        <span>Jump to…</span>
        <kbd>⌘K</kbd>
      </div>

      <div className="std-scroll">
        {NAV.slice(0, 3).map((sect, si) => (
          <div key={si} className="std-section">
            <div className="std-label">{sect.section}</div>
            {sect.items.map((item, i) => (
              <a key={i} href="#" className={`std-item ${item.active ? 'is-active' : ''}`}>
                <span className="std-marker">{item.active ? '›' : ''}</span>
                <span className="std-icon">{Icons[item.icon]}</span>
                <span className="std-label-txt">{item.label}</span>
                {item.hot && <span className="std-hot">{Icons.flame}</span>}
                {item.badge && <span className="std-badge std-badge-live"><span className="live-dot"/>{item.badge}</span>}
                {item.count != null && !item.badge && (
                  <span className={`std-count ${item.dot ? 'std-count-alert' : ''}`}>{item.count}</span>
                )}
              </a>
            ))}
          </div>
        ))}

        {/* Boost meter */}
        <div className="ws-boost">
          <div className="ws-boost-head">
            <span className="std-label-mono">BOOST · TIER 2</span>
            <span className="ws-boost-val">68%</span>
          </div>
          <div className="ws-boost-bar"><div className="ws-boost-fill" style={{ width: '68%' }}/></div>
          <div className="ws-boost-meta">
            <span>2,840 / 4,200 MON staked</span>
            <a href="#" className="ws-boost-link">Boost →</a>
          </div>
        </div>

        {/* Activity stream */}
        <div className="std-section">
          <div className="std-label std-label-pinned">
            <span>Activity</span>
            <span className="ws-act-pulse"/>
          </div>
          <div className="ws-feed">
            <div className="ws-feed-row">
              <span className="ws-feed-time">14:32</span>
              <span className="ws-feed-tag ws-tag-buy">SOLD</span>
              <span className="ws-feed-txt">CodeReviewer-v3 → 0x9a…</span>
            </div>
            <div className="ws-feed-row">
              <span className="ws-feed-time">14:18</span>
              <span className="ws-feed-tag ws-tag-msg">MSG</span>
              <span className="ws-feed-txt">offer received +0.4 MON</span>
            </div>
            <div className="ws-feed-row">
              <span className="ws-feed-time">13:51</span>
              <span className="ws-feed-tag ws-tag-stake">STAKE</span>
              <span className="ws-feed-txt">+200 MON · tier↑</span>
            </div>
          </div>
        </div>
      </div>

      <div className="std-footer">
        <div className="std-foot-top">
          <div className="std-foot-net">
            <span className="ws-net-dot"/>
            <span className="std-foot-mono">0x4f2a…E91c</span>
          </div>
          <button className="std-foot-disconnect">disconnect</button>
        </div>
        <div className="std-foot-bal">
          <div>
            <div className="std-foot-bal-num">12.847</div>
            <div className="std-foot-bal-lbl">MON · $4,218.20</div>
          </div>
          <button className="std-foot-bal-btn">Buy →</button>
        </div>
      </div>
    </aside>
  );
}

window.SidebarVariants = { rail: RailSidebar, standard: StandardSidebar, workspace: WorkspaceSidebar };
window.NavIcons = Icons;
