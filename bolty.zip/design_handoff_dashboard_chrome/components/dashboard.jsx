/* global React */
const { useMemo } = React;

function Sparkline({ color = '#836EF9', up = true }) {
  const pts = useMemo(() => {
    const n = 24;
    let v = 50;
    const out = [];
    for (let i = 0; i < n; i++) {
      v += (Math.random() - (up ? 0.4 : 0.6)) * 14;
      v = Math.max(10, Math.min(90, v));
      out.push([i / (n - 1) * 100, 100 - v]);
    }
    return out;
  }, [up]);
  const d = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p[0]} ${p[1]}`).join(' ');
  const fill = `${d} L 100 100 L 0 100 Z`;
  return (
    <svg viewBox="0 0 100 50" preserveAspectRatio="none" className="kpi-spark" style={{ width: '100%' }}>
      <defs>
        <linearGradient id={`g-${color}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity=".3"/>
          <stop offset="100%" stopColor={color} stopOpacity="0"/>
        </linearGradient>
      </defs>
      <path d={fill} fill={`url(#g-${color})`}/>
      <path d={d} fill="none" stroke={color} strokeWidth="1.4"/>
    </svg>
  );
}

function Dashboard() {
  return (
    <div className="dash">
      <div className="dash-hero">
        <div className="dash-greet">
          <h1>Welcome back, <b>Aroii</b></h1>
          <p>3 negotiations awaiting your response · last login 2h ago from Madrid</p>
        </div>
        <div className="dash-actions">
          <button className="dash-act-btn">Import repo</button>
          <button className="dash-act-btn dash-act-primary">+ New agent</button>
        </div>
      </div>

      <div className="kpi-grid">
        <div className="kpi">
          <div className="kpi-lbl">Revenue · 30D</div>
          <div className="kpi-val">$4,218.20</div>
          <div className="kpi-delta">↑ 12.4% vs prev</div>
          <Sparkline color="#22c55e" up/>
        </div>
        <div className="kpi">
          <div className="kpi-lbl">Active orders</div>
          <div className="kpi-val">28</div>
          <div className="kpi-delta">↑ 3 new today</div>
          <Sparkline color="#836EF9" up/>
        </div>
        <div className="kpi">
          <div className="kpi-lbl">Agent calls</div>
          <div className="kpi-val">12.4K</div>
          <div className="kpi-delta is-down">↓ 2.1% vs prev</div>
          <Sparkline color="#ef4444" up={false}/>
        </div>
        <div className="kpi">
          <div className="kpi-lbl">Reputation</div>
          <div className="kpi-val">4.92<span style={{fontSize:12, color:'var(--text-4)', marginLeft:4}}>/5</span></div>
          <div className="kpi-delta">↑ 18 reviews</div>
          <Sparkline color="#06b6d4" up/>
        </div>
      </div>

      <div className="dash-cols">
        <div className="dash-card">
          <div className="dash-card-head">
            <div className="dash-card-title">Recent transactions</div>
            <div className="dash-card-sub">Last 24h · 8</div>
          </div>
          {[
            { t: '14:32', n: 'CodeReviewer-v3', sub: '0x9a4f…2e81 · sale', a: '+0.420 MON', s: 'CONFIRMED', pos: true },
            { t: '13:51', n: 'Stake deposit', sub: 'tier 2 · auto-compound', a: '+200.00 MON', s: 'BLOCK 8492110', pos: true },
            { t: '11:08', n: 'monorepo-toolkit', sub: '0x33b1…4d09 · license', a: '+1.250 MON', s: 'CONFIRMED', pos: true },
            { t: '09:44', n: 'Gas refund', sub: 'failed deploy 0x7e…', a: '-0.012 MON', s: 'REVERTED', pos: false },
            { t: '08:17', n: 'price-oracle.eth', sub: '0xb2c4…ff10 · subscription', a: '+0.080 MON', s: 'CONFIRMED', pos: true },
          ].map((r, i) => (
            <div className="tx-row" key={i}>
              <div className="tx-time">{r.t}</div>
              <div className="tx-name">{r.n}<small>{r.sub}</small></div>
              <div className={`tx-amt ${r.pos ? 'is-pos' : 'is-neg'}`}>{r.a}</div>
              <div className="tx-status">{r.s}</div>
            </div>
          ))}
        </div>

        <div className="dash-card">
          <div className="dash-card-head">
            <div className="dash-card-title">Trending agents</div>
            <div className="dash-card-sub">Live · 24h</div>
          </div>
          {[
            { c: '#836EF9', i: 'CR', n: 'CodeReviewer-v3', m: '482 calls · 4.9★', p: '0.42 MON' },
            { c: '#06B6D4', i: 'MT', n: 'monorepo-toolkit', m: '291 calls · 4.8★', p: '1.25 MON' },
            { c: '#EC4899', i: 'PO', n: 'price-oracle.eth', m: '188 calls · 5.0★', p: '0.08 MON' },
            { c: '#F59E0B', i: 'AG', n: 'auditgen', m: '142 calls · 4.7★', p: '0.65 MON' },
            { c: '#22C55E', i: 'SQ', n: 'sql-fixer', m: '98 calls · 4.6★', p: '0.21 MON' },
          ].map((a, i) => (
            <div className="agent-row" key={i}>
              <div className="agent-mark" style={{ background: a.c }}>{a.i}</div>
              <div>
                <div className="agent-name">{a.n}</div>
                <div className="agent-meta">{a.m}</div>
              </div>
              <div className="agent-price">{a.p}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

window.Dashboard = Dashboard;
