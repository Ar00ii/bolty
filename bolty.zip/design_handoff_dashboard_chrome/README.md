# Handoff: Bolty Dashboard Chrome (Sidebar + Navbar redesign)

## Overview
Redesign of the dashboard chrome (sidebar + top navbar) for the Bolty platform — a Web3 agent / repo marketplace running on Monad. The goal is to remove the duplicate navigation that exists today (the current `Navbar.tsx` repeats Marketplace / Agents / Repos / Chat / Services / Docs links that the `Sidebar.tsx` already owns) and tighten the visual language to a single, terminal-precision aesthetic.

This handoff redesigns:
- `frontend/src/components/layout/Sidebar.tsx` (new sectioned sidebar with workspace switcher, pinned items, wallet footer)
- `frontend/src/components/layout/Navbar.tsx` (new contextual top bar with breadcrumbs, ⌘K command, ticker, network pill, notifications, avatar)
- `frontend/src/components/layout/ClientShell.tsx` (small adjustment — drop the legacy `UnifiedHeader` / `FloatingTopBar` when the sidebar is shown)

## About the Design Files
The files in this bundle are **design references created in HTML** — a working React + plain CSS prototype showing the intended look, layout and behavior. They are **not production code to copy directly**.

The task is to **recreate these designs inside the existing Bolty codebase** (Next.js 14 App Router + TypeScript + TailwindCSS + lucide-react + framer-motion), reusing its established patterns:
- Tailwind utility classes (the prototype uses plain CSS — convert to Tailwind, lifting tokens from `tailwind.config.js`)
- `lucide-react` icons (the prototype uses inline SVGs — swap in lucide equivalents)
- `next/link` for navigation (the prototype uses `<a href="#">`)
- `usePathname()` from `next/navigation` for active-route detection
- Existing `useAuth()` (`@/lib/auth/AuthProvider`) for user/wallet info
- Existing `useTheme()` (`@/lib/theme/ThemeContext`) for dark/light if relevant
- Keep `framer-motion` for the few subtle animations, but DO NOT restore the heavy per-item motion that the old sidebar had — restraint is part of the redesign

## Fidelity
**High-fidelity (hifi).** Pixel-perfect — final colors, spacing, typography, hover states. Match the prototype exactly. Color values, spacing in px, typography sizes and weights are all final.

## Files Included
| File | Purpose |
|---|---|
| `Bolty Dashboard.html` | Entry point — mounts the React app, wires Tweaks panel |
| `styles.css` | All visual tokens & component styles (your source of truth for colors / spacing / typography) |
| `components/sidebar.jsx` | Three sidebar variants. **Implement the `standard` variant** — that's what the user picked. `rail` and `workspace` are bonus references. |
| `components/navbar.jsx` | Two navbar variants. **Implement the `power` variant** — that's what the user picked. `minimal` is a fallback. |
| `components/dashboard.jsx` | Mock dashboard content used to show the chrome in context — **not part of the redesign**, just so you can see how the chrome wraps real content |

## What to Build

### Sidebar — `StandardSidebar` (variant the user selected)

**Width:** 264px, fixed, full viewport height, `position: sticky; top: 0`. Border-right `1px solid #1f1f23`. Background `#0c0c0f`.

**Structure (top → bottom):**

1. **Workspace switcher** — header row, height 56px, padding `0 14px`, border-bottom hairline.
   - 30×30 brand mark on the left: rounded 8px, gradient `linear-gradient(135deg, #836EF9 0%, #5b3fd1 100%)`, white "B" in JetBrains Mono 600 14px, inner shadow `inset 0 0 0 1px rgba(255,255,255,.08)`, drop shadow `0 4px 14px rgba(131,110,249,.25)`.
   - Two-line meta: workspace name (Inter 13px / 400 / `#e4e4e7`) + network pill row below (`6px green dot with 8px glow` + mono 10.5px "Monad Mainnet" in `#71717a`).
   - Right: `ChevronsUpDown` icon (lucide), 14px, `#52525b`.
   - Whole row is a button; hover background `rgba(255,255,255,.02)`.

2. **Search trigger** — margin `12px 12px 8px`, padding `7px 10px`. Background `#09090b`, border `1px solid #1f1f23`, radius 8px. Lucide `Search` 12px on the left, "Jump to…" text, mono `⌘K` chip on the right (background `#18181b`, border `1px solid #2a2a30`, padding `2px 5px`, radius 4px, font 10px). Clicking should open a command palette (use [`cmdk`](https://cmdk.paco.me) — recommended).

3. **Sections** — scrollable middle area, padding `4px 8px 12px`. For each section:
   - Section label: JetBrains Mono 10px, letter-spacing `.12em`, uppercase, `#52525b`, padding `0 10px 6px`, margin-top 16px.
   - Items: 4-col grid `10px 16px 1fr auto`, gap 10px, padding `7px 10px`, radius 6px, font Inter 13px / 300 / `#a1a1aa`.
     - Col 1: "›" (mono, `#836EF9`) when active, blank otherwise.
     - Col 2: lucide icon 16px, color `#71717a` (`#a594ff` when active or hovered).
     - Col 3: label, white-space nowrap.
     - Col 4 (rightmost meta — only one of these per item):
       - `count` → mono 10.5px pill, padding `1px 6px`, radius 999px, background `#18181b`, border `1px solid #1f1f23`, color `#52525b`. If `dot=true`, becomes a solid purple alert pill: `background: #836EF9, color: white, no border`.
       - `badge` (e.g. "128 live") → mono 10px chip with a 5px green pulsing dot.
       - `hot` → lucide `Flame` 14px, `#f59e0b`.
       - `kbd` (e.g. "G O") → mono 10px, `#52525b`, opacity 0 → 1 on row hover.
   - Active item: background `rgba(131,110,249,.08)`, text `#e4e4e7`, icon `#a594ff`.
   - Hover: text `#e4e4e7`, background `rgba(255,255,255,.03)`.

4. **Pinned section** — same shape as a regular section, but the label row also has a `+` button on the right. Items use a 7×7 colored square (border-radius 2px) instead of an icon, and the label uses JetBrains Mono 11.5px (these are user-pinned shortcuts, often agent / repo names).

5. **Wallet footer** — fixed at bottom, border-top hairline, padding 12px, background `linear-gradient(180deg, transparent, rgba(131,110,249,.04))`.
   - Top row: green dot + truncated mono address `0x4f2a…E91c` on the left, mono 10px "disconnect" link on the right (hover → `#ef4444`).
   - Bottom card: padding `10px 12px`, background `#121214`, border `1px solid #1f1f23`, radius 8px. Left: balance number in JetBrains Mono 18px / 400 (`12.847`), label below in mono 10.5px `#52525b` (`MON · $4,218.20`). Right: solid purple "Buy →" button (`#836EF9`, white, padding `6px 10px`, radius 6px, font 12px).

**Section data (lift directly from the prototype's `NAV` constant):**
```ts
[
  { section: 'Workspace', items: [
    { label: 'Overview',   icon: 'Home',  href: '/',        kbd: 'G O' },
    { label: 'My Profile', icon: 'User',  href: '/profile', kbd: 'G P' },
  ]},
  { section: 'Marketplace', items: [
    { label: 'Agents',       icon: 'Bot',       href: '/market/agents', count: 1284, hot: true },
    { label: 'Repositories', icon: 'GitBranch', href: '/market/repos',  count: 892 },
    { label: 'Services',     icon: 'Briefcase', href: '/services',      count: 47 },
  ]},
  { section: 'Network', items: [
    { label: 'Global Chat', icon: 'Globe',          href: '/chat', badge: '128 live' },
    { label: 'Messages',    icon: 'MessageSquare',  href: '/dm',   count: 3, dot: true },
    { label: 'Boost',       icon: 'Zap',            href: '/profile?tab=agent' },
  ]},
  { section: 'Resources', items: [
    { label: 'API Keys', icon: 'Key',      href: '/api-keys' },
    { label: 'Docs',     icon: 'BookOpen', href: '/docs/agent-protocol' },
    { label: 'Settings', icon: 'Settings', href: '/profile?tab=security' },
  ]},
]
```
Counts / badges should come from real data later (number of unread DMs, live chat users, agent listings) — for now use the placeholder values.

### Navbar — `PowerNavbar` (variant the user selected)

**Height:** 56px, sticky top, padding `0 18px`, border-bottom `1px solid #1f1f23`, background `rgba(9,9,11,.85)` with `backdrop-filter: blur(10px)`. Lays out: `crumbs · ticker · spacer · search · CTA · divider · network · bell · avatar`, all with 12px gap.

1. **Breadcrumbs** — derive from `usePathname()`. Each segment is a `<Link>`, 13px Inter 300, `#71717a`. Last segment is `#e4e4e7` / 400. Separators are mono `/` in `#52525b`.

2. **Inline ticker** — pill at `margin-left: 18px`, padding `5px 14px`, background `#0c0c0f`, border `1px solid #1f1f23`, radius 999px. Three blocks separated by 1px hairline dividers (14px tall):
   - `MON $0.328 +4.21%` (delta in green `#22c55e`)
   - `GAS 12 gwei`
   - `RAYS 2,847 +18` (delta in green)
   Labels: mono 10px `#52525b` letter-spacing `.08em`. Values: mono 11px `#e4e4e7`. Deltas: mono 10.5px green/red.
   These should be wired to your existing market data / Socket.io stream — see `frontend/src/lib/socket.ts` if present.

3. **Spacer** — `flex: 1`.

4. **Command search** (`nav-cmd`) — width 360px (max 36vw), padding `7px 10px`, background `#0c0c0f`, border `1px solid #1f1f23`, radius 8px. Lucide `Search` 13px + "Search agents, repos, addresses, tx…" placeholder + `⌘K` chips on the right. Same `cmdk` palette as the sidebar trigger — they should both open the same overlay.

5. **"Deploy agent" CTA** — primary button, padding `6px 11px`, radius 8px, background `#836EF9`, white, font 12.5px / 400. Lucide `Plus` 13px on the left. Shadow `0 0 0 1px rgba(131,110,249,.3), 0 4px 14px rgba(131,110,249,.25)`. Hover → `#a594ff`. Active scale `.97`. Routes to `/agents/new` (or wherever your existing "create agent" flow lives — there's `CreateAgentModal.tsx` in components/agents).

6. **Hairline divider** — 1×22px, `#1f1f23`.

7. **Network pill** — padding `5px 10px`, background `#0c0c0f`, border `1px solid #1f1f23`, radius 999px, mono 11px `#a1a1aa`. Content: `[6px green dot + glow] Monad · #8,492,118`. Block height should poll your RPC / your existing block subscription.

8. **Notification bell** — 32×32 button, radius 8px. Lucide `Bell` 15px, `#71717a`. Hover background `rgba(255,255,255,.04)`. Badge: top-right, min-width 14px / height 14px, padding `0 3px`, radius 7px, purple background, mono 9px / 600 white text, 1.5px border in page background color (creates a "cut-out" effect). Hidden when count is 0.

9. **Avatar** — 28×28 circle, gradient `linear-gradient(135deg, #ec4899, #836EF9)`, white initials in JetBrains Mono 10.5px, 1px white-10% border. Green status dot bottom-right (9×9, 2px page-bg border). Wrapper button has 3px padding so the dot doesn't get clipped, hover background `rgba(255,255,255,.04)`. Click opens a dropdown menu — you can keep the existing `profileOpen` dropdown logic from the old `Navbar.tsx`, just restyle the dropdown to match (background `#121214`, border `#2a2a30`, radius 12px).

### `ClientShell.tsx` adjustment

The current shell renders `<FloatingTopBar/>` always and `<UnifiedHeader/>` when there's no sidebar. With the redesign:
- Drop `<FloatingTopBar/>` entirely (its functions move into the new Navbar).
- Keep `<UnifiedHeader/>` only for the landing/auth pages (as it does today via `!showSidebar`).
- Render the new `<Navbar/>` inside the main flex column, above `<main>`, when the sidebar is shown.
- Remove the `pt-16` (the new Navbar is sticky and handles its own height).

```tsx
<div className="flex">
  {showSidebar && <Sidebar />}
  <div className="flex-1 w-full flex flex-col">
    {showSidebar && <Navbar />}
    <main className="flex-1 relative min-h-screen">{children}</main>
    {!isHome && !isAuth && <Footer />}
  </div>
</div>
```

## Design Tokens

**Colors (zinc + Monad purple, exact values):**
| Token | Value | Use |
|---|---|---|
| `--bg` | `#09090b` | page background |
| `--bg-2` | `#0c0c0f` | sidebar background, search/ticker pills |
| `--bg-card` | `#121214` | cards, dropdowns, wallet card |
| `--bg-elev` | `#18181b` | counts, kbd chips |
| `--border` | `#1f1f23` | hairlines |
| `--border-2` | `#2a2a30` | hover hairlines, dropdown borders |
| `--text` | `#e4e4e7` | primary text |
| `--text-2` | `#a1a1aa` | secondary text |
| `--text-3` | `#71717a` | tertiary / placeholders |
| `--text-4` | `#52525b` | quaternary / mono labels |
| `--accent` | `#836EF9` | Monad purple — already in `tailwind.config.js` as `monad-400` |
| `--accent-2` | `#a594ff` | active icons, links |
| `--accent-bg` | `rgba(131,110,249,.08)` | active item background |
| `--accent-bd` | `rgba(131,110,249,.22)` | accent borders |
| `--green` | `#22c55e` | live, positive deltas, status |
| `--red` | `#ef4444` | alerts, negative deltas, disconnect hover |
| `--amber` | `#f59e0b` | hot / trending markers |

These map cleanly to your existing `tailwind.config.js` — `monad-400` = accent, `terminal-bg` = `--bg`, `terminal-card` = `--bg-card` (replace with `#121214`), `terminal-border` = `--border` (replace with `#1f1f23`).

**Typography:**
- Sans: Inter 300/400/500 (already loaded)
- Mono: JetBrains Mono 400/500 — add to your `<head>` or use the existing `font-mono` Tailwind class, but **prefer JetBrains Mono** over the system stack for consistency
- Scales used: 9.5, 10, 10.5, 11, 11.5, 12, 12.5, 13, 13.5, 14, 18 px

**Spacing:** mostly 2/4/6/8/10/12/14/16/18px increments.

**Radii:** 4 (chips), 6 (small items), 8 (buttons / cards / search), 10 (large cards), 999 (pills).

**Shadows:**
- Brand mark: `inset 0 0 0 1px rgba(255,255,255,.08), 0 4px 14px rgba(131,110,249,.25)`
- Primary CTA: `0 0 0 1px rgba(131,110,249,.3), 0 4px 14px rgba(131,110,249,.25)`
- Status dot: `0 0 8px rgba(34,197,94,.5)` (green glow)

**Animations:**
- `pulse` — `50% { opacity: .35; }` 1.6s infinite, used on the live dot in badges and the activity-stream pulse.
- All transitions: `120ms` for color/background, `80ms` for active scale on buttons. **Keep it minimal** — do not reintroduce framer-motion's per-item enter animations from the old sidebar. The user explicitly wanted it tighter.

## State & Data Wiring
- **User / avatar / wallet address** → `useAuth()` from `@/lib/auth/AuthProvider`
- **Active route** → `usePathname()` from `next/navigation`
- **Network block #** → existing RPC client (look for `lib/web3` or similar)
- **MON price / gas / RAYS** → wherever your existing market data lives (`hooks/useNegotiation.ts` is in `app/market/agents/hooks/` — there may be other hooks)
- **Pinned items** → new feature; persist to `localStorage` keyed by user, or to your backend `/profile` if you want cross-device sync
- **Notifications count** → existing notifications system (the old Navbar already had a `<Bell>` — reuse whatever fed it)
- **Counts on Marketplace items** (1284 agents, 892 repos, 47 services) → fetch on mount, cache in React Query / SWR if you use either

## Interactions
- **⌘K / `/`** anywhere → open command palette (sidebar search and navbar search both trigger it)
- **Click workspace switcher** → opens a dropdown listing other workspaces (out of scope here — wire to backend later, just stub the open state)
- **Click avatar** → reuse the existing `profileOpen` dropdown from the old `Navbar.tsx` (Profile / Orders / API Keys / Settings / Sign out), restyled to the new card style
- **Click "Buy →"** in wallet footer → open buy/swap modal (out of scope, link to `/profile?tab=billing` for now)
- **Click "Deploy agent"** → open `CreateAgentModal` (already exists at `frontend/src/components/agents/CreateAgentModal.tsx`)
- **Click "disconnect"** → call existing `logout()` from `useAuth`, or your wallet disconnect handler

## Responsive
The prototype is desktop-only. For mobile (< 1024px):
- Sidebar collapses to a slide-out drawer behind a hamburger trigger (the existing Sidebar.tsx already had this — port the `isMobile` / `isOpen` logic over).
- Navbar drops the ticker and the breadcrumbs (keep only the brand mark, search icon trigger, bell, avatar).
- The wallet footer card should still be visible inside the open drawer.

## Assets
No new image assets. All visual elements are CSS / SVG / lucide icons. The brand mark is a CSS gradient with a "B" glyph — no logo file needed (if you have a real wordmark, swap it in but keep the same 30×30 footprint).

## Acceptance Checklist
- [ ] Old `NAV_LINKS` horizontal links are removed from the navbar (no duplication with sidebar)
- [ ] Sidebar uses sectioned mono labels (not the old "Navigation" header)
- [ ] Active item shows the `›` glyph + purple background + accent icon (no animated bullet, no gradient bar)
- [ ] Wallet card visible at the bottom of the sidebar, address truncated, balance in mono
- [ ] Navbar shows breadcrumbs from the URL, not a logo or hamburger
- [ ] Ticker pulls live data (or stubbed values that look real)
- [ ] ⌘K opens a real command palette
- [ ] Notification badge has the "cut-out" border effect (1.5px page-bg border around the badge)
- [ ] No framer-motion entrance animations on individual sidebar items
- [ ] Dark theme only for now (the existing `useTheme` light theme can be wired later — match light tokens to the same hierarchy)

## Reference
Open `Bolty Dashboard.html` in any browser to see the working prototype. The Tweaks panel (bottom-right) lets you toggle between sidebar/navbar variants — confirm the implementation matches the `standard` sidebar + `power` navbar combination (the user's selected default).
